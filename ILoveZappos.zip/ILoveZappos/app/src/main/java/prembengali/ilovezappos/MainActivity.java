package prembengali.ilovezappos;

import android.content.Context;
import android.databinding.BindingAdapter;
import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.os.Vibrator;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;

import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.SearchView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.List;

import prembengali.ilovezappos.databinding.ProductPageBinding;
import prembengali.ilovezappos.model.Product;
import prembengali.ilovezappos.model.ProductResponse;
import prembengali.ilovezappos.rest.ApiClient;
import prembengali.ilovezappos.rest.ApiInterface;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by Prem on 2/6/2017.
 * This class gets the data from the Product class
 * and ApiClient and uses data binding to create the product page
 */
public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private static final String TAG = MainActivity.class.getSimpleName();


    /* Floating Action Button */
    public static FloatingActionButton fab;

    /* Brand name of the product */
    private String brandName;

    /* Color id of the product */
    private Integer colorId;

    /*Original price of the product */
    private String originalPrice;

    /* Percent off on the product */
    private String percentOff;

    /* Discounted price of the product */
    private String price;

    /* Product id of the product */
    private String productId;

    /* Name of the product */
    private String productName;

    /* Product URL */
    private String productUrl;

    /* Style id of the product */
    private Integer styleId;

    /* Thumbnail Url of the product */
    private String thumbnailImageUrl;

    /* Data binding object */
    ProductPageBinding binding;

    /* Add to cart button */
    Button addbtn;


    /**
     * OnCreate method to create the activity screen
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = DataBindingUtil.setContentView(this, R.layout.product_page);

        fab = (FloatingActionButton) findViewById(R.id.fab);

        addbtn = (Button) findViewById(R.id.addBtn);

        fab.setOnClickListener(this);
        addbtn.setOnClickListener(this);

    }

    /**
     * This method helps to take user input as query and
     * get the data from the server and store the data into strings
     *
     * @param menu is the search menu
     * @return
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        // Generates the search view
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_search, menu);
        MenuItem item = menu.findItem(R.id.menuSearch);
        SearchView searchView = (SearchView) item.getActionView();

        //Takes in the query
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {

            /**
             * This method waits until the query is submitted and
             * uses it as a term to search for the data with the api key
             * @param query is the user input from the search bar
             * @return false as search view handles the query
             */
            @Override
            public boolean onQueryTextSubmit(String query) {

                ApiInterface apiService =
                        ApiClient.getClient().create(ApiInterface.class);

                Call<ProductResponse> call = apiService.getProductDetails(query, getResources()
                        .getString(R.string.API_KEY));

                call.enqueue(new Callback<ProductResponse>() {
                    @Override
                    public void onResponse(Call<ProductResponse> call,
                                           Response<ProductResponse> response) {

                        // List of the products
                        List<Product> productList = response.body().getResults();


                        //Storing the data into fields

                        brandName = "by " + productList.get(0).getBrandName();
                        colorId = productList.get(0).getColorId();

                        percentOff = productList.get(0).getPercentOff();

                        // If the product is not on sale, we will not display
                        // percentoff and the new price

                        if (percentOff.equals("0%")) {
                            originalPrice = "Price : " + productList.get(0).getOriginalPrice();
                            price = "";
                        } else {
                            originalPrice = "Was : " + productList.get(0).getOriginalPrice();
                            price = "Now : " + productList.get(0).getPrice() + " ("
                                    + percentOff + " off)";
                        }

                        productId = "Product ID : " + productList.get(0).getProductId();
                        productName = productList.get(0).getProductName();
                        productUrl = productList.get(0).getProductUrl();
                        styleId = productList.get(0).getStyleId();
                        thumbnailImageUrl = productList.get(0).getThumbnailImageUrl();

                        // Creating a product with the values returned
                        Product product1 = new Product(brandName, colorId, originalPrice,
                                percentOff, price, productId, productName, productUrl, styleId,
                                thumbnailImageUrl);

                        binding.setProduct(product1);
                    }


                    @Override
                    public void onFailure(Call<ProductResponse> call, Throwable t) {
                        //Log error here since request failed
                        Log.e(TAG, toString());
                    }
                });
                Log.i("well", " this worked");
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                return false;
            }
        });

        return super.onCreateOptionsMenu(menu);
    }


    /**
     * This method is used to load image from url using
     * data binding and Picasso
     *
     * @param view     is where you would load the image
     * @param imageUrl is the url of the photo
     */
    @BindingAdapter({"bind:imageUrl"})
    public static void loadImage(ImageView view, String imageUrl) {
        Picasso.with(view.getContext())
                .load(imageUrl)
                .into(view);
    }

    /***
     * OnClick method for add to cart button
     * When add to cart button is clicked
     * FLoating action button does animation
     * and vibrates
     * @param view is the button that is clicked
     */
    @Override
    public void onClick(View view) {
        if(view == addbtn) {
            Animation animation = AnimationUtils.loadAnimation(this, R.anim.floating_button_animation);
            fab.startAnimation(animation);
            Vibrator vibe = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
            vibe.vibrate(100);
        }
    }
}// end class MainActivity

