package prembengali.ilovezappos.rest;

import prembengali.ilovezappos.model.ProductResponse;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

/**
 * Created by Prem on 2/6/2017.
 * An interface helps which calls the server through the query inserted
 * and retrieves the description of the project
 */
public interface ApiInterface{

    @GET("Search")
    Call<ProductResponse> getProductDetails(@Query("term") String term, @Query("key") String apiKey);

}//end interface ApiInterface
