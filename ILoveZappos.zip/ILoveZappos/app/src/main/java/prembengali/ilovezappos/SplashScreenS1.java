package prembengali.ilovezappos;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;

import prembengali.ilovezappos.MainActivity;
import prembengali.ilovezappos.R;

/**
 * Created by Prem on 2/6/2017.
 * This is a splash screen which opens at the start of the app
 *
 */
public class SplashScreenS1 extends Activity {

    /**
     * Oncreate method to set the splash screen
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.splash_screen_s1);

       final TextView v = (TextView) findViewById(R.id.rotText);

        // Using the rotation as our animation
        final Animation an = AnimationUtils.loadAnimation(getBaseContext(), R.anim.rotate);

        v.startAnimation(an);  //Starting the animation

        an.setAnimationListener(new Animation.AnimationListener() {

            /**
             * This method has to be called as a part of Animation Listener
             * But we do not use it
             * @param animation is the animation we want to use
             */
            @Override
            public void onAnimationStart(Animation animation) {
                //Do nothing
            }

            /**
             * This method helps use to go to screen 2 when we finish the
             * animation
             * @param animation is the animation we want to use
             */
            @Override
            public void onAnimationEnd(Animation animation) {
                finish();
                Intent i = new Intent(getBaseContext(),MainActivity.class);
                startActivity(i);

            }

            /**
             * This method has to be called as a part of Animation Listener
             * But we do not use it
             * @param animation is the animation we want to use
             */
            @Override
            public void onAnimationRepeat(Animation animation) {
                //Do nothing
            }
        });
    }
}
