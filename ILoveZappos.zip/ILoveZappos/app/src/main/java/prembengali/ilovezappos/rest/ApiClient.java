package prembengali.ilovezappos.rest;

import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

/**
 * Created by Prem on 2/6/2017.
 *
 * This class is an example of using REST
 * It uses retrofit library to convert the JSON query into java objects
 *
 */
public class ApiClient {

    /* Base Url of the prodcut */
    public static final String BASE_URL = "https://api.zappos.com/";
    /* Retrofit object to convert the JSON query */
    private static Retrofit retrofit = null;

    /**
     * This method helps tp get the client
     * @return the retrofit object
     */
    public static Retrofit getClient() {
        if (retrofit == null) {
            retrofit = new Retrofit.Builder()
                    .baseUrl(BASE_URL)
                    .addConverterFactory(GsonConverterFactory.create())
                    .build();

        }
        return retrofit;
    }
}//end class ApiClient
